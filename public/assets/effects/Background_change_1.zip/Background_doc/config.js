Background = require('bnb_js/background');
Background.texture("back.jpg")